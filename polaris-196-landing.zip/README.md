# POLARIS 196 — Minimal Landing Page

This package contains a single `index.html` you can upload to your web host.

## Quick deploy on Namecheap (cPanel hosting)
1. Log in to Namecheap → **Hosting List** → **Manage** (for your hosting plan) → **cPanel** → **File Manager**.
2. Open the `public_html` folder (the web root).
3. Click **Upload** and upload `index.html` from this folder.
4. If there's an existing `index.html` (or `index.php`) you want to keep, rename it first (e.g., `old-index.php`).

Your site should now show the POLARIS 196 landing page.

## If you're using WordPress (e.g., EasyWP)
WordPress serves `index.php` by default, so uploading `index.html` won't take effect. Use one of these options:

**A. Set a simple "Home" page**
1. In WordPress Admin → **Pages → Add New** → title: `POLARIS 196`.
2. Content: `POLARIS 196` on first line, and on the next line *building things?* (italic). Publish.
3. Go to **Settings → Reading** → set **Your homepage displays** to **A static page**, choose your new page as **Homepage**.
4. (Optional) Add this CSS in **Appearance → Customize → Additional CSS** to center and style:
```css
body { margin:0; min-height:100vh; display:grid; place-items:center; background:#0b0d10; color:#e7edf3; }
h1 { font-size: clamp(2.5rem,8vw,8rem); letter-spacing:.08em; font-weight:800; margin:0; }
p em { color:#9aa7b2; font-size: clamp(1rem,3.2vw,1.5rem); }
```

**B. Use a "Coming Soon" plugin**
Install a lightweight coming-soon/maintenance plugin and set the headline to `POLARIS 196` and the subtext to *building things?*

## SFTP upload (alternative)
1. In Namecheap, find your SFTP/FTP credentials (Hosting → Manage).
2. Connect with an SFTP client to your server.
3. Upload `index.html` to `/public_html`.

## DNS (only if your domain isn't pointing yet)
- Set your domain's nameservers to Namecheap BasicDNS (or your host's nameservers).
- Or create an A record for `@` (and `www` CNAME to `@`) pointing to your hosting IP.

